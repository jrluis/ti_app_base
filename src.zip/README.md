iphone & android app skeleton
=====
This is a javascript skeleton to create app's for iphone and android in titanium.

Folder structure
-----
The ui is in the controls and windows folder.
In the common folder there are facades to provide data, commands to make actions 
independent of the ui, and the navigation controller, that makes transitions between
windows.

Notes
----
On the top of every file, there is a funcional specification of that component.